#include<iostream>
using namespace std;
main (){
cout<<"        _________________" << endl;
cout<<"       |                 |" << endl;
cout<<"     __|                 |_____" << endl;
cout<<"    |_____ _____________  _____|" << endl;
cout<<"          O              O" << endl;
}