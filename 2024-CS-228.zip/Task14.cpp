#include <iostream>
using namespace std;

main() {
    cout << "   (\\__/)\n";
    cout << "   (o^.^)\n";
    cout << "  z(_(\")(\")\n";
    cout << "   Pikachu!\n";
}
