#include<iostream>
using namespace std;
main(){
cout<<"          /\\" <<endl;
cout<<"       __/~~\\__" <<endl;
cout<<"     /   |  |   \\" <<endl;
cout<<"    =====.  .=====" <<endl;
cout<<"         ||||" <<endl;
}