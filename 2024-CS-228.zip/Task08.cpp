#include<iostream>
using namespace std;
main(){
system("color 37");
cout<<".....          *****    *****  th        ....." << endl;
cout<<"......        **   **  **   **          ......" << endl;
cout<<".......          ***   **   **         ......." << endl;
cout<<".......         **     **   **         ......." << endl;
cout<<"  .......     *******   *****         ......." << endl;
cout<<"    .....    ____________________    ......." << endl;
cout<<"     ....    C  E  N  T  U  R  Y    ....." << endl;
cout<<"      ...    ____________________   ..." << endl;
cout<<"    __| |__                       __| |__" << endl;
cout<<"   |       |                     |       |" << endl;
cout<<"____________________________________________" << endl;
}   
