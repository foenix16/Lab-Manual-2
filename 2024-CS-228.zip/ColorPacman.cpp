#include<iostream>
using namespace std;
main(){
system("color 97");
cout<<"     .::---::.."<< endl;
cout<<"  .--------------." << endl;
cout<<" .-----------------." << endl;
cout<<" -----------------:." << endl;
cout<<":-------------::." << endl;
cout<<"-------------:." << endl;
cout<<":---------------:.." << endl;
cout<<" :-----------------:." << endl;
cout<<"   .:------------:." << endl;
cout<<"    .::---::...." << endl;
}