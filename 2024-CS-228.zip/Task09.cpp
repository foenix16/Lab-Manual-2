#include<iostream>
using namespace std;
main(){
system("color 8E");
cout <<"----------------------------" << endl;
cout <<"    o  ^__^" << endl;
cout <<"     o (oo)\\_______" << endl;
cout <<"       (__)\\       )\\/\\" << endl;
cout <<"          ----------" << endl;
cout <<"         ||         |" << endl;
cout <<"         ||        ||" << endl;
} 